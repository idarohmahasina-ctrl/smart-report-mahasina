
import React, { useState, useEffect } from 'react';
import { UserProfile, Role } from './types';
import LoginView from './views/LoginView';
import DashboardView from './views/DashboardView';
import Sidebar from './components/Sidebar';
import AttendanceView from './views/AttendanceView';
import ReportsView from './views/ReportsView';
import InformationView from './views/InformationView';

export type View = 'dashboard' | 'absen-guru' | 'absen-santri' | 'pelanggaran' | 'prestasi' | 'info';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('mahasina_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (profile: UserProfile) => {
    setUser(profile);
    localStorage.setItem('mahasina_user', JSON.stringify(profile));
  };

  const handleLogout = () => {
    localStorage.removeItem('mahasina_user');
    setUser(null);
  };

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!user) {
    return <LoginView onLogin={handleLogin} />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <DashboardView user={user} />;
      case 'absen-guru': return <AttendanceView user={user} type="guru" />;
      case 'absen-santri': return <AttendanceView user={user} type="santri" />;
      case 'pelanggaran': return <ReportsView user={user} type="violation" />;
      case 'prestasi': return <ReportsView user={user} type="achievement" />;
      case 'info': return <InformationView user={user} />;
      default: return <DashboardView user={user} />;
    }
  };

  const getViewTitle = () => {
    switch (currentView) {
      case 'dashboard': return 'Dashboard Utama';
      case 'absen-guru': return 'Presensi Kehadiran Guru';
      case 'absen-santri': return 'Absensi Kehadiran Santri';
      case 'pelanggaran': return 'Laporan Kedisiplinan & Pelanggaran';
      case 'prestasi': return 'Laporan Prestasi Santri';
      case 'info': return 'Informasi & Struktur Organisasi';
      default: return '';
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        user={user} 
        onLogout={handleLogout} 
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <header className="mb-8">
          <h1 className="text-2xl font-bold text-slate-800">
            Assalamu'alaikum, <span className="text-emerald-600">{user.name}</span>
          </h1>
          <p className="text-slate-500 text-sm font-medium">{getViewTitle()}</p>
        </header>
        {renderView()}
      </main>
    </div>
  );
};

export default App;
