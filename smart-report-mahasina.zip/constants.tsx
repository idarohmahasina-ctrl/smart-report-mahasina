
import { ClassInfo, Student, Level, Gender } from './types';

export const CLASSES: ClassInfo[] = [
  { id: '7a', name: '7A', level: Level.MTS, gender: Gender.PUTRA },
  { id: '7b', name: '7B', level: Level.MTS, gender: Gender.PUTRI },
  { id: '10a', name: '10A', level: Level.MA, gender: Gender.PUTRA },
  { id: '10b', name: '10B', level: Level.MA, gender: Gender.PUTRI },
];

export const INITIAL_STUDENTS: Student[] = [
  { id: 's1', nis: '2023001', name: 'Ahmad Fauzi', gender: Gender.PUTRA, level: Level.MTS, classId: '7a' },
  { id: 's2', nis: '2023002', name: 'Budi Santoso', gender: Gender.PUTRA, level: Level.MTS, classId: '7a' },
  { id: 's3', nis: '2023003', name: 'Siti Aminah', gender: Gender.PUTRI, level: Level.MTS, classId: '7b' },
  { id: 's4', nis: '2023004', name: 'Zahra Laila', gender: Gender.PUTRI, level: Level.MTS, classId: '7b' },
  { id: 's5', nis: '2024001', name: 'Muhammad Ali', gender: Gender.PUTRA, level: Level.MA, classId: '10a' },
  { id: 's6', nis: '2024002', name: 'Fatimah Az-Zahra', gender: Gender.PUTRI, level: Level.MA, classId: '10b' },
];

export const VIOLATION_TYPES = [
  { type: 'Ibadah', defaultPoints: 5 },
  { type: 'Kedisiplinan', defaultPoints: 10 },
  { type: 'Akhlak', defaultPoints: 15 },
  { type: 'Lainnya', defaultPoints: 0 },
];
