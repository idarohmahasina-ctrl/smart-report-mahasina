
import React from 'react';
import { Role, UserProfile } from '../types';
import { View } from '../App';
import { 
  LayoutDashboard, 
  UserCheck, 
  Users, 
  AlertTriangle, 
  Trophy, 
  Info, 
  LogOut
} from 'lucide-react';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
  user: UserProfile;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: Object.values(Role) },
    { 
      id: 'absen-guru', 
      label: 'Absen Guru', 
      icon: UserCheck, 
      roles: [Role.GURU, Role.MUSYRIF, Role.IDAROH, Role.PENGASUH] 
    },
    { 
      id: 'absen-santri', 
      label: 'Absen Santri', 
      icon: Users, 
      roles: [Role.GURU, Role.MUSYRIF, Role.IDAROH, Role.PENGASUH] 
    },
    { 
      id: 'pelanggaran', 
      label: 'Pelanggaran', 
      icon: AlertTriangle, 
      roles: Object.values(Role) // All roles can see violations but with different scopes
    },
    { 
      id: 'prestasi', 
      label: 'Prestasi', 
      icon: Trophy, 
      roles: Object.values(Role)
    },
    { id: 'info', label: 'Informasi', icon: Info, roles: Object.values(Role) },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col hidden md:flex">
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">
            M
          </div>
          <div className="overflow-hidden">
            <h2 className="font-bold text-slate-800 truncate">Smart Mahasina</h2>
            <p className="text-xs text-slate-400 font-medium">{user.role}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Menu Utama</p>
        {menuItems.filter(item => item.roles.includes(user.role)).map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as View)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              currentView === item.id 
                ? 'bg-emerald-50 text-emerald-700' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <item.icon size={20} className={currentView === item.id ? 'text-emerald-600' : 'text-slate-400'} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="px-4 py-2 mb-2">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Akun</p>
          <p className="text-sm font-bold text-slate-700 truncate">{user.name}</p>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-600 hover:bg-rose-50 transition-colors"
        >
          <LogOut size={20} />
          Keluar
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
