
import React, { useState } from 'react';
import { Role, UserProfile } from '../types';
import { CLASSES } from '../constants';

interface LoginViewProps {
  onLogin: (profile: UserProfile) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<Partial<UserProfile>>({
    role: Role.GURU,
    managedClasses: [],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      const finalUser: UserProfile = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name || '',
        email: formData.email || '',
        phone: formData.phone || '',
        role: formData.role || Role.GURU,
        managedClasses: formData.managedClasses || [],
      };
      onLogin(finalUser);
    }
  };

  const toggleClass = (classId: string) => {
    const current = formData.managedClasses || [];
    if (current.includes(classId)) {
      setFormData({ ...formData, managedClasses: current.filter(id => id !== classId) });
    } else {
      setFormData({ ...formData, managedClasses: [...current, classId] });
    }
  };

  return (
    <div className="min-h-screen bg-emerald-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-xl overflow-hidden">
        <div className="bg-emerald-600 p-8 text-white text-center">
          <div className="w-16 h-16 bg-white/20 rounded-2xl mx-auto mb-4 flex items-center justify-center">
            <span className="text-3xl font-bold">M</span>
          </div>
          <h1 className="text-2xl font-bold">Smart Report</h1>
          <p className="text-emerald-100">Pesantren Mahasina</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {step === 1 ? (
            <>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nama Lengkap</label>
                  <input
                    required
                    type="text"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                    placeholder="Masukkan nama lengkap"
                    value={formData.name || ''}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                  <input
                    required
                    type="email"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                    placeholder="nama@email.com"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Telepon</label>
                  <input
                    required
                    type="tel"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                    placeholder="0812..."
                    value={formData.phone || ''}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Pilih Peran</label>
                  <select
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as Role })}
                  >
                    {Object.values(Role).map((role) => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-600 text-white font-bold py-4 rounded-xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
              >
                Lanjutkan
              </button>
            </>
          ) : (
            <>
              {formData.role === Role.MUSYRIF ? (
                <div className="space-y-4">
                  <h3 className="font-bold text-slate-800">Pilih Kelas yang Diampu</h3>
                  <p className="text-sm text-slate-500">Musyrif/ah dapat mengampu lebih dari 1 kelas.</p>
                  <div className="grid grid-cols-2 gap-3">
                    {CLASSES.map((cls) => (
                      <button
                        key={cls.id}
                        type="button"
                        onClick={() => toggleClass(cls.id)}
                        className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                          formData.managedClasses?.includes(cls.id)
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-200 text-slate-600 hover:border-emerald-300'
                        }`}
                      >
                        Kelas {cls.name}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-4 py-8">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full mx-auto flex items-center justify-center">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-slate-600 font-medium">Profil Anda siap digunakan.</p>
                </div>
              )}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex-1 px-4 py-4 rounded-xl font-bold text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors"
                >
                  Kembali
                </button>
                <button
                  type="submit"
                  className="flex-[2] bg-emerald-600 text-white font-bold py-4 rounded-xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
                >
                  Selesaikan Pendaftaran
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
};

export default LoginView;
