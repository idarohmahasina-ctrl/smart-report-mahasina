
import React, { useState } from 'react';
import { UserProfile, Role } from '../types';
import { INITIAL_STUDENTS, VIOLATION_TYPES } from '../constants';
import { Search, Plus, AlertCircle, Trophy, FileText, Download, Filter, UserCheck } from 'lucide-react';

interface ReportsViewProps {
  user: UserProfile;
  type: 'violation' | 'achievement';
}

const ReportsView: React.FC<ReportsViewProps> = ({ user, type }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showForm, setShowForm] = useState(false);

  // Filter students for the report form based on role
  const searchableStudents = user.role === Role.MUSYRIF && user.managedClasses?.length
    ? INITIAL_STUDENTS.filter(s => user.managedClasses?.includes(s.classId))
    : INITIAL_STUDENTS;

  // Mock data filtered by managed classes if user is Musyrif
  const mockViolations = [
    { id: '1', student: 'Ahmad Fauzi', class: '7A', type: 'Ibadah', points: 5, date: '2023-10-20', status: 'Ditindak', reporter: 'Ust. Rahman' },
    { id: '2', student: 'Muhammad Ali', class: '10A', type: 'Akhlak', points: 15, date: '2023-10-19', status: 'Pending', reporter: 'Ustz. Sarah' },
  ].filter(r => user.role === Role.IDAROH || user.role === Role.PENGASUH || user.role === Role.SANTRI_STAFF || (user.role === Role.MUSYRIF && user.managedClasses?.includes(r.class.toLowerCase())));

  const mockAchievements = [
    { id: 'a1', student: 'Siti Aminah', class: '7B', type: 'Tahfidz', points: 20, date: '2023-10-21', status: 'Verifikasi', reporter: 'Ustz. Zahra' },
    { id: 'a2', student: 'Budi Santoso', class: '7A', type: 'Lomba MSQ', points: 50, date: '2023-10-18', status: 'Selesai', reporter: 'Ust. Ali' },
  ].filter(r => user.role === Role.IDAROH || user.role === Role.PENGASUH || user.role === Role.SANTRI_STAFF || (user.role === Role.MUSYRIF && user.managedClasses?.includes(r.class.toLowerCase())));

  const reports = type === 'violation' ? mockViolations : mockAchievements;
  const themeColor = type === 'violation' ? 'rose' : 'amber';
  const themeIcon = type === 'violation' ? <AlertCircle size={24} /> : <Trophy size={24} />;

  const canExport = [Role.IDAROH, Role.PENGASUH, Role.MUSYRIF].includes(user.role);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className={`p-3 bg-${themeColor}-50 text-${themeColor}-600 rounded-2xl`}>
            {themeIcon}
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Total Laporan</p>
            <p className="text-2xl font-bold text-slate-800">{reports.length}</p>
          </div>
        </div>
        
        <div className="md:col-span-2 flex justify-end items-center gap-3">
          <button 
            onClick={() => setShowForm(true)}
            className={`bg-${themeColor}-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-${themeColor}-700 transition-all shadow-xl shadow-${themeColor}-100`}
          >
            <Plus size={20} />
            Input {type === 'violation' ? 'Pelanggaran' : 'Prestasi'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-100 flex flex-wrap gap-4 items-center justify-between bg-slate-50/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder={`Cari nama santri...`}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-white border border-slate-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
             {canExport && (
               <button className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 flex items-center gap-2 hover:bg-slate-50 transition-all text-xs font-bold uppercase tracking-wider">
                 <Download size={16} />
                 Download Rekap
               </button>
             )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold tracking-widest">
              <tr>
                <th className="px-6 py-4">Santri</th>
                <th className="px-6 py-4">Detail</th>
                <th className="px-6 py-4">Poin</th>
                <th className="px-6 py-4">Pelapor</th>
                <th className="px-6 py-4">Status</th>
                {user.role === Role.IDAROH && <th className="px-6 py-4 text-center">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {reports.length > 0 ? reports.map((report) => (
                <tr key={report.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-800">{report.student}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Kelas {report.class}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-slate-600 font-medium">{report.type}</span>
                    <p className="text-[10px] text-slate-400">{report.date}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm ${
                      type === 'violation' ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                    }`}>
                      {type === 'violation' ? '-' : '+'}{report.points}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-slate-700">{report.reporter}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      report.status === 'Ditindak' || report.status === 'Selesai' 
                        ? 'bg-emerald-100 text-emerald-700' 
                        : `bg-${themeColor}-100 text-${themeColor}-700`
                    }`}>
                      {report.status}
                    </span>
                  </td>
                  {user.role === Role.IDAROH && (
                    <td className="px-6 py-4">
                      <div className="flex justify-center">
                        <button className="text-emerald-600 hover:text-emerald-700 font-bold text-xs">Edit</button>
                      </div>
                    </td>
                  )}
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                    Belum ada data laporan yang tersedia.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-xl rounded-[32px] overflow-hidden shadow-2xl">
            <div className={`p-8 text-white flex justify-between items-center bg-${themeColor}-600`}>
              <div>
                <h3 className="text-2xl font-bold">Lapor {type === 'violation' ? 'Pelanggaran' : 'Prestasi'}</h3>
                <p className={`text-${themeColor}-100 text-sm`}>Oleh: {user.name} ({user.role})</p>
              </div>
              <button onClick={() => setShowForm(false)} className="bg-white/20 hover:bg-white/30 p-2.5 rounded-2xl transition-colors">
                <Plus className="rotate-45" size={24} />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Nama Santri</label>
                  <select className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-medium">
                    <option>Pilih Santri...</option>
                    {searchableStudents.map(s => <option key={s.id}>{s.name} ({s.classId.toUpperCase()})</option>)}
                  </select>
                  {user.role === Role.MUSYRIF && <p className="text-[10px] text-slate-400 mt-1 italic">*Hanya santri di kelas ampu Anda yang muncul</p>}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Kategori</label>
                    <select className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 outline-none font-medium">
                      {type === 'violation' ? (
                         VIOLATION_TYPES.map(vt => <option key={vt.type}>{vt.type}</option>)
                      ) : (
                         ['Tahfidz', 'Akademik', 'Akhlakul Karimah', 'Lomba/Kompetisi'].map(at => <option key={at}>{at}</option>)
                      )}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Poin</label>
                    <input type="number" className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 outline-none font-bold text-emerald-600" defaultValue={10} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-2">Kronologi / Deskripsi</label>
                  <textarea rows={3} className="w-full px-5 py-4 rounded-2xl bg-slate-50 border border-slate-200 outline-none resize-none font-medium" placeholder="Tuliskan detail kejadian..."></textarea>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl flex items-center gap-3">
                  <UserCheck className="text-emerald-600" size={18} />
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">Pelapor Otomatis</p>
                    <p className="text-sm font-bold text-slate-700">{user.name}</p>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => { alert('Laporan Berhasil Terkirim!'); setShowForm(false); }}
                className={`w-full py-5 rounded-[20px] font-bold text-white shadow-xl transition-all bg-${themeColor}-600 hover:bg-${themeColor}-700 shadow-${themeColor}-100`}
              >
                Kirim Laporan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsView;
