
import React, { useState, useEffect } from 'react';
import { UserProfile, Role, AttendanceStatus } from '../types';
import { CLASSES, INITIAL_STUDENTS } from '../constants';
import { Check, UserCheck, Users, Calendar, ShieldAlert } from 'lucide-react';

interface AttendanceViewProps {
  user: UserProfile;
  type: 'guru' | 'santri';
}

const AttendanceView: React.FC<AttendanceViewProps> = ({ user, type }) => {
  // Filter classes based on role: Musyrif only sees their classes
  const availableClasses = user.role === Role.MUSYRIF && user.managedClasses?.length 
    ? CLASSES.filter(c => user.managedClasses?.includes(c.id))
    : CLASSES;

  const [selectedClass, setSelectedClass] = useState(availableClasses[0]?.id || '');
  const [attendance, setAttendance] = useState<Record<string, { status: AttendanceStatus; remark: string }>>({});

  useEffect(() => {
    if (!availableClasses.find(c => c.id === selectedClass)) {
      setSelectedClass(availableClasses[0]?.id || '');
    }
  }, [availableClasses, selectedClass]);

  const filteredStudents = INITIAL_STUDENTS.filter(s => s.classId === selectedClass);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId] || { remark: '' }, status }
    }));
  };

  const handleRemarkChange = (studentId: string, remark: string) => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId] || { status: AttendanceStatus.HADIR }, remark }
    }));
  };

  const saveAttendance = () => {
    alert(`Laporan Absensi dikirim oleh: ${user.name}\nData disinkronkan ke idarohmahasina@gmail.com`);
  };

  if (type === 'guru') {
    return (
      <div className="space-y-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-6 shadow-sm">
          <div className="w-24 h-24 bg-emerald-50 text-emerald-600 rounded-3xl mx-auto flex items-center justify-center">
            <UserCheck size={48} />
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-bold text-slate-800">Presensi Guru Pengajar</h3>
            <p className="text-slate-500 max-w-md mx-auto">
              Presensi mandiri untuk Bapak/Ibu Guru Mahasina.
            </p>
          </div>
          
          <div className="bg-slate-50 p-6 rounded-2xl flex items-center justify-between max-w-lg mx-auto border border-slate-100">
             <div className="text-left">
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Guru Terdeteksi</p>
               <p className="font-bold text-slate-800 text-lg">{user.name}</p>
             </div>
             <div className="text-right">
               <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status Akun</p>
               <p className="font-bold text-emerald-600 text-lg">{user.role}</p>
             </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <button className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200">
              Mulai Sesi Mengajar
            </button>
            <button disabled className="bg-slate-100 text-slate-400 px-10 py-4 rounded-2xl font-bold">
              Selesai & Lapor
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {user.role === Role.MUSYRIF && (
        <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex items-center gap-3 text-amber-700 shadow-sm">
          <ShieldAlert size={20} />
          <p className="text-sm font-medium">Anda sedang mengakses dashboard Musyrif/ah. Data terbatas pada kelas ampunan Anda.</p>
        </div>
      )}

      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-100 flex flex-wrap gap-4 items-center justify-between">
          <div className="flex items-center gap-4">
            <label className="text-sm font-bold text-slate-700">Pilih Kelas:</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="bg-slate-50 px-4 py-2 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-slate-700"
            >
              {availableClasses.map(c => (
                <option key={c.id} value={c.id}>Kelas {c.name}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-3 text-slate-500">
            <Users size={18} />
            <span className="text-sm font-medium">{filteredStudents.length} Santri</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold tracking-widest">
              <tr>
                <th className="px-6 py-4">Santri</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Keterangan Khusus</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length > 0 ? filteredStudents.map((student) => {
                const current = attendance[student.id] || { status: AttendanceStatus.HADIR, remark: '' };
                return (
                  <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-bold text-slate-800">{student.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">NIS: {student.nis}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-1">
                        {[
                          { val: AttendanceStatus.HADIR, color: 'emerald', label: 'H' },
                          { val: AttendanceStatus.SAKIT, color: 'amber', label: 'S' },
                          { val: AttendanceStatus.IZIN, color: 'orange', label: 'I' },
                          { val: AttendanceStatus.TERLAMBAT, color: 'indigo', label: 'T' },
                          { val: AttendanceStatus.ALPHA, color: 'rose', label: 'A' },
                        ].map((st) => (
                          <button
                            key={st.val}
                            onClick={() => handleStatusChange(student.id, st.val)}
                            className={`w-9 h-9 rounded-xl font-bold text-xs flex items-center justify-center transition-all ${
                              current.status === st.val
                                ? `bg-${st.color}-600 text-white shadow-lg shadow-${st.color}-200`
                                : `bg-${st.color}-50 text-${st.color}-600 hover:bg-${st.color}-100`
                            }`}
                          >
                            {st.label}
                          </button>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <input
                        type="text"
                        placeholder="Alasan khusus..."
                        className="bg-slate-50 px-4 py-2.5 rounded-xl border border-transparent focus:border-emerald-200 focus:bg-white outline-none w-full text-sm transition-all"
                        value={current.remark}
                        onChange={(e) => handleRemarkChange(student.id, e.target.value)}
                      />
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-slate-400 italic">
                    Tidak ada data santri untuk kelas ini.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
          <p className="text-xs text-slate-400 font-medium italic">Nama Pelapor: <span className="font-bold">{user.name}</span></p>
          <button
            onClick={saveAttendance}
            disabled={filteredStudents.length === 0}
            className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200 disabled:opacity-50 disabled:shadow-none"
          >
            <Check size={20} />
            Simpan & Sinkronkan
          </button>
        </div>
      </div>
    </div>
  );
};

export default AttendanceView;
