
import React from 'react';
import { UserProfile, Role } from '../types';
import { INITIAL_STUDENTS, CLASSES } from '../constants';
import { Users, BookOpen, UserCircle, Briefcase } from 'lucide-react';

interface InformationViewProps {
  user: UserProfile;
}

const InformationView: React.FC<InformationViewProps> = ({ user }) => {
  const sections = [
    { id: 'guru', label: 'Data Guru', icon: UserCircle },
    { id: 'siswa', label: 'Data Santri', icon: Users },
    { id: 'jadwal', label: 'Jadwal Pelajaran', icon: BookOpen },
    { id: 'orsam', label: 'ORSAM / ORKLAS', icon: Briefcase },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {sections.map(section => (
          <button key={section.id} className="bg-white p-6 rounded-3xl border border-slate-200 hover:border-emerald-500 hover:shadow-lg transition-all group text-left">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl w-fit mb-4 group-hover:bg-emerald-600 group-hover:text-white transition-all">
              <section.icon size={24} />
            </div>
            <h3 className="font-bold text-slate-800">{section.label}</h3>
            <p className="text-xs text-slate-400 mt-1">Ketuk untuk lihat detail</p>
          </button>
        ))}
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-bold text-slate-800">Daftar Santri Aktif</h2>
          {user.role === Role.IDAROH && (
            <button className="text-emerald-600 font-bold text-sm hover:underline">Edit Data</button>
          )}
        </div>

        <div className="space-y-6">
          {CLASSES.map(cls => (
            <div key={cls.id}>
              <h3 className="font-bold text-slate-400 text-xs uppercase tracking-widest mb-4">Kelas {cls.name} - {cls.level} ({cls.gender})</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {INITIAL_STUDENTS.filter(s => s.classId === cls.id).map(student => (
                  <div key={student.id} className="p-4 bg-slate-50 rounded-2xl flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center font-bold text-emerald-600 shadow-sm">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-slate-800 text-sm">{student.name}</p>
                      <p className="text-xs text-slate-500">NIS: {student.nis}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Organizational Structure Mock */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <div className="w-2 h-6 bg-emerald-600 rounded-full"></div>
            ORSAM Putra
          </h3>
          <div className="space-y-4">
             <div className="flex justify-between items-center pb-4 border-b border-slate-50">
               <span className="text-sm font-medium text-slate-500">Ketua Umum</span>
               <span className="text-sm font-bold text-slate-800">Muhammad Wildan</span>
             </div>
             <div className="flex justify-between items-center pb-4 border-b border-slate-50">
               <span className="text-sm font-medium text-slate-500">Sekretaris</span>
               <span className="text-sm font-bold text-slate-800">Ahmad Rizky</span>
             </div>
             <div className="flex justify-between items-center">
               <span className="text-sm font-medium text-slate-500">Bendahara</span>
               <span className="text-sm font-bold text-slate-800">Fikri Haikal</span>
             </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200">
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <div className="w-2 h-6 bg-emerald-600 rounded-full"></div>
            ORSAM Putri
          </h3>
          <div className="space-y-4">
             <div className="flex justify-between items-center pb-4 border-b border-slate-50">
               <span className="text-sm font-medium text-slate-500">Ketua Umum</span>
               <span className="text-sm font-bold text-slate-800">Luthfia Zahra</span>
             </div>
             <div className="flex justify-between items-center pb-4 border-b border-slate-50">
               <span className="text-sm font-medium text-slate-500">Sekretaris</span>
               <span className="text-sm font-bold text-slate-800">Annisa Fitri</span>
             </div>
             <div className="flex justify-between items-center">
               <span className="text-sm font-medium text-slate-500">Bendahara</span>
               <span className="text-sm font-bold text-slate-800">Salsabila</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InformationView;
