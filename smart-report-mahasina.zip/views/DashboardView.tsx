
import React from 'react';
import { UserProfile, AttendanceStatus } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, Legend 
} from 'recharts';
import { Users, AlertCircle, Award, CheckCircle } from 'lucide-react';

interface DashboardViewProps {
  user: UserProfile;
}

const DashboardView: React.FC<DashboardViewProps> = ({ user }) => {
  // Mock Stats Data
  const stats = [
    { label: 'Total Kehadiran', value: '94%', sub: '+2% dari pekan lalu', icon: CheckCircle, color: 'emerald' },
    { label: 'Pelanggaran Baru', value: '12', sub: 'Status: 8 ditindak', icon: AlertCircle, color: 'rose' },
    { label: 'Prestasi Siswa', value: '24', sub: 'Pekan ini', icon: Award, color: 'amber' },
    { label: 'Total Santri', value: '540', sub: 'MA: 210, MTs: 330', icon: Users, color: 'indigo' },
  ];

  const attendanceData = [
    { name: 'Sen', hadir: 95, sakit: 2, izin: 2, alpha: 1 },
    { name: 'Sel', hadir: 92, sakit: 3, izin: 3, alpha: 2 },
    { name: 'Rab', hadir: 96, sakit: 1, izin: 2, alpha: 1 },
    { name: 'Kam', hadir: 94, sakit: 2, izin: 3, alpha: 1 },
    { name: 'Jum', hadir: 88, sakit: 5, izin: 4, alpha: 3 },
    { name: 'Sab', hadir: 97, sakit: 1, izin: 1, alpha: 1 },
  ];

  const COLORS = ['#10b981', '#fbbf24', '#f59e0b', '#f43f5e'];

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-xl bg-${stat.color}-50 text-${stat.color}-600`}>
                <stat.icon size={24} />
              </div>
            </div>
            <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
            <p className="text-2xl font-bold text-slate-800 mt-1">{stat.value}</p>
            <p className="text-xs text-slate-400 mt-1">{stat.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Trends */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-6">Statistik Kehadiran Santri (Harian)</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={attendanceData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend iconType="circle" />
                <Bar dataKey="hadir" name="Hadir" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="sakit" name="Sakit" fill="#fbbf24" radius={[4, 4, 0, 0]} />
                <Bar dataKey="izin" name="Izin" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="alpha" name="Alpha" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Violations Ranking */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="font-bold text-slate-800 mb-4">Paling Banyak S/I/T/A</h3>
          <div className="space-y-4">
            {[
              { name: 'Ahmad Fauzi', class: '7A', count: 8, status: 'Alpha' },
              { name: 'Muhammad Ali', class: '10A', count: 5, status: 'Izin' },
              { name: 'Budi Santoso', class: '7A', count: 4, status: 'Sakit' },
              { name: 'Zahra Laila', class: '7B', count: 3, status: 'Izin' },
              { name: 'Siti Aminah', class: '7B', count: 2, status: 'Alpha' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-400 text-xs">
                    {i + 1}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{item.name}</p>
                    <p className="text-xs text-slate-500">Kelas {item.class}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-slate-800">{item.count}</span>
                  <p className="text-[10px] text-rose-500 font-medium uppercase tracking-wider">{item.status}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-3 text-sm font-semibold text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors">
            Lihat Semua Laporan
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
