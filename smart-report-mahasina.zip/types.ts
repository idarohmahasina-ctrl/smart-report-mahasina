
export enum Role {
  GURU = 'Guru',
  MUSYRIF = 'Musyrif/ah',
  IDAROH = 'Petugas Idaroh',
  SANTRI_STAFF = 'Petugas Santri',
  PENGASUH = 'Pengasuh'
}

export enum AttendanceStatus {
  HADIR = 'H',
  SAKIT = 'S',
  IZIN = 'I',
  TERLAMBAT = 'T',
  ALPHA = 'A'
}

export enum Gender {
  PUTRA = 'Putra',
  PUTRI = 'Putri'
}

export enum Level {
  MTS = 'MTs',
  MA = 'MA'
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: Role;
  managedClasses?: string[]; // For Musyrif
}

export interface Student {
  id: string;
  nis: string;
  name: string;
  gender: Gender;
  level: Level;
  classId: string;
}

export interface ClassInfo {
  id: string;
  name: string;
  level: Level;
  gender: Gender;
}

export interface SantriAttendance {
  id: string;
  studentId: string;
  status: AttendanceStatus;
  date: string;
  teacherId: string;
  remarks?: string;
}

export interface GuruAttendance {
  id: string;
  guruId: string;
  subject: string;
  startTime: string;
  endTime: string;
  date: string;
}

export interface Violation {
  id: string;
  studentId: string;
  type: string;
  points: number;
  description: string;
  reporterId: string;
  date: string;
  status: 'pending' | 'resolved';
}

export interface Achievement {
  id: string;
  studentId: string;
  title: string;
  points: number;
  description: string;
  reporterId: string;
  date: string;
}
